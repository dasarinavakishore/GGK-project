﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataLayer;
namespace BALayer
{
    internal class BALAuthenticate : IAuthenticaltionBAL
    {
        DALAuthenticate _DALObj;

        public BALAuthenticate()
        {
            _DALObj = new DALAuthenticate();
        }

        public bool BALIsValidUser(string userName, string pwd)
        {
            return _DALObj.DALIsValidUser(userName, pwd);
        }
    }
}
