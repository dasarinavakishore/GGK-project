﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BALayer
{
    public static class BALFactory
    {
        public static IAuthenticaltionBAL GetAuthObject()
        {
            return new BALAuthenticate();
        }
    }
}
