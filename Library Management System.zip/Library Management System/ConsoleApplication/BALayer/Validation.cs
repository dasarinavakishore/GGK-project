﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BALayer
{
    public static class Validation
    {
        public static bool IsUserNameValid(string userName)
        {
            return true;
        }

        public static bool IsPasswordValid(string pwd)
        {
            return true;
        }
    }
}
