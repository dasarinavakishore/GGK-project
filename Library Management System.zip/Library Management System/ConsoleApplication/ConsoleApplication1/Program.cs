﻿using System;
using System.Threading.Tasks;
using BALayer;

namespace Login
{
    class Program
    {
        static void Main(string[] args)
        {
            string s = "Library Login\n";
            Console.SetCursorPosition((Console.WindowWidth - s.Length) / 2, Console.CursorTop);
            Console.WriteLine(s);
            Console.Write("UserName: ");
            string UserName=Console.ReadLine();
            Console.Write("Password: ");
            string Password= Console.ReadLine();
            if (Validation.IsUserNameValid(UserName) && Validation.IsPasswordValid(Password))
            {
                IAuthenticaltionBAL BALObj = BALFactory.GetAuthObject();

                if (BALObj.BALIsValidUser(UserName, Password))
                {
                    Console.WriteLine("\nLogin Success");
                    Console.ReadLine();
                }
                else
                {
                    Console.WriteLine("\nInvalid Credentials");
                    Console.ReadLine();
                }
            }
            int choice = 1, bookcount = 0,bookid = 100;
            Console.WriteLine("Choose the options:\n");
            Console.WriteLine("\nMenu\n" +"1)Add book\n" + "2)Search book\n" + "3)Issue book\n" + "4)Return book\n" + "5)Close\n\n");
            Console.ReadLine();
            choice = Convert.ToInt16(Console.ReadLine());
            switch(choice)
            {
                case 1:
                    Console.WriteLine("Enter the name of the book and the author's name: ");
                    string bookname = Convert.ToString(Console.ReadLine());
                    string author = Convert.ToString(Console.ReadLine());
                    bookcount++;
                    bookid++;

                    break;
            }
        }

        //public booklist(string bookname, string bookid, string bookauthor, string bookremarks)
       // {
        //book booklist = new book();
        //}
    }
}