﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer
{
    public class DALAuthenticate : IAuthenticaltionDAL
    {
        public bool DALIsValidUser(string userName, string pwd)
        {
            //database
            if (userName == "kkk" & pwd == "nnn")
            {
                return true;
            }

            return false;
        }
    }
    //static List<book> bookList = new List<book>();
    //{
    
}
